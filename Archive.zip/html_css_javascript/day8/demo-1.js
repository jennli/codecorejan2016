document.addEventListener("DOMContentLoaded", function(event){
  console.log("hi");

var outputDiv = document.getElementById("output");
// outputDiv.innerHTML = "Hello <strong>World</strong>!";
var now = new Date();
outputDiv.innerHTML = now;

})
