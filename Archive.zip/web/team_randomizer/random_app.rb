require "sinatra"
require "sinatra/reloader"
get "/" do
  erb :pick_rand, layout: :random_layout
end

post "/pick_random" do
  @students_arr = params[:names].split(",")
  @num_of_team = params[:team_count].to_i

  shuffled_names_arr = shuffleNames(@students_arr)

  n = shuffled_names_arr.length

  # in average, i have avg_count number of people in each team to start with
  avg_count = n / @num_of_team

  # being being left out
  left_out = n %  @num_of_team
  @arr_of_teams ||= []

  p shuffled_names_arr

  i = 0
  while i < n - left_out 
    p i
    (i..(avg_count+i-1)).map{|c| shuffled_names_arr[c]}.compact
    #
    # @arr_of_teams.push((i..(avg_count+i-1)).map{|c| shuffled_names_arr[c]})

    p @arr_of_teams

    i+=avg_count;
  end
  p @arr_of_teams
  i -= avg_count;
  p i

  (0...left_out).each do |f|
    p @arr_of_teams[f].push(shuffled_names_arr[i+f])
  end

  erb :pick_rand, layout: :random_layout


end

def shuffleNames(arr)
  # fisher-yates algorithm

  for i in 1..arr.length
    random_student = rand(0..arr.length-1) # pick a random student
    tempHold = arr[i];
    arr[i] = arr[random_student];
    arr[random_student] = tempHold;
  end

  arr.compact

end
