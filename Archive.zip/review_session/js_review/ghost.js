var Ghost = function(){
  this.color = ["red", "yellow", "pink", "white"][Math.floor(Math.random()*4)];
  this.getInfo = "Ghost";
}
