function Ball (ballType) {
  this.type = ballType === undefined ? "regular" : ballType ;
  this.getInfo = "Ball";

}
