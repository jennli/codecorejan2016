var PacMan = function(){
  this.extraLives = 2;
  this.points = 0;
  this.superTime = 0;
}

Pacman.prototype = {

eat: function(object){
    if (object.getInfo === "Ball" ){
      eatBall(object);
    }
    else{
      eatGhost(object);
    }
  },

eatGhost: function(ghost){
    // raise PacmanErrors::BadFoodError.new("Don't feed me that!!!") unless ghost.class == Ghost
    if(PacMan.prototype.superTime > 0){
      PacMan.prototype.points += 250000;
    }
    else{
      die();
    }
  },

  var eatBall = function(ball){
    PacMan.prototype.superTime -= 1;
    if (ball.ballType === "regular"){
      PacMan.prototype.points +=1000;
    }
    else{
      PacMan.prototype.superTime = 10;
    }
  };

  var die = function(){
    PacMan.prototype.extraLives -=1;
    if(PacMan.prototype.extraLives < 0){
      gameOver();
    }
  };

  var gameOver(){
    console.log("!!!!!!!!!!POINTS: "+ PacMan.prototype.points+"!!!!!!!!!!GAME OVER!!!!!!!!!!";
  }
};
