class Food
  attr_accessor :carbs, :fat

  def initialize(carbs, protein, fat)
    @carbs, @protein, @fat = carbs, protein, fat
  end

end
