module HelperMethod

  def caught
    chance = rand(1..100)
    chance > 50
  end
end
