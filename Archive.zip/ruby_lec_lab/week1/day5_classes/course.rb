class Course

  attr_accessor :name, :grade

  def initialize (name, grade)
    @name, @grade = name, grade
  end

end
