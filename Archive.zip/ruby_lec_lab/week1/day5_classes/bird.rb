require "./animal.rb"

class Bird < Animal

def catch_prey
  super
end

def eat
  super
end

end
