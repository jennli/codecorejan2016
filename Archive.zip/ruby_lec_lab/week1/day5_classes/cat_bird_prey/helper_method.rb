module HelperMethod

  def caught
    x = rand(1..100)
    puts "#{x}"
    x > 50

  end

end
