# a = [nil, 3, nil, 4]
#
# puts a.compact!
# puts a.size
#
# #making string sentence into an array of words
# puts "give me a string sentence: "
#
# sentence = gets.chomp
#
# array_words = sentence.split()
#
# print array_words
# puts
